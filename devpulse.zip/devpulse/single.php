<?php
/**
 * The template for displaying all single posts
 *
 * @package DevPulse
 */

get_header();
?>

<div class="single-post-wrapper">
    <?php
    while ( have_posts() ) :
        the_post();

        // Load the single content partial
        get_template_part( 'template-parts/content', 'single' );

        // If comments are open or we have at least one comment, load comments template
        if ( comments_open() || get_comments_number() ) :
            comments_template();
        endif;

    endwhile;
    ?>
</div>

<?php
get_footer();
