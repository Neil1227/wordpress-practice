<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package DevPulse
 */

get_header();

// Hero Partial with 404 message
get_template_part( 'template-parts/hero', null, array(
    'badge'    => 'Error 404',
    'title'    => 'Page Not Found',
    'subtitle' => 'The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.',
) );

// Reuse content-none partial
get_template_part( 'template-parts/content', 'none' );

get_footer();
