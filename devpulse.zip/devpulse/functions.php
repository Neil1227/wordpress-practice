<?php
/**
 * DevPulse Theme Functions and Definitions
 *
 * @package DevPulse
 */

if ( ! function_exists( 'devpulse_setup' ) ) :
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     */
    function devpulse_setup() {
        // Let WordPress manage the document title
        add_theme_support( 'title-tag' );

        // Enable support for Post Thumbnails on posts and pages
        add_theme_support( 'post-thumbnails' );
        set_post_thumbnail_size( 640, 360, true );

        // Register Primary Navigation Menu
        register_nav_menus( array(
            'primary-menu' => esc_html__( 'Primary Header Menu', 'devpulse' ),
        ) );

        // Switch default core markup for search form, comment form, etc. to HTML5
        add_theme_support( 'html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ) );
    }
endif;
add_action( 'after_setup_theme', 'devpulse_setup' );

/**
 * Enqueue scripts and styles.
 */
function devpulse_scripts() {
    wp_enqueue_style( 'devpulse-style', get_stylesheet_uri(), array(), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'devpulse_scripts' );

/**
 * Custom excerpt length filter
 */
function devpulse_custom_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'devpulse_custom_excerpt_length', 999 );

/**
 * Custom excerpt more string
 */
function devpulse_excerpt_more( $more ) {
    return '&hellip;';
}
add_filter( 'excerpt_more', 'devpulse_excerpt_more' );
