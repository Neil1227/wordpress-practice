<?php
/**
 * Template part for displaying static page content
 *
 * @package DevPulse
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-article page-article' ); ?>>
    <header class="single-header">
        <h1 class="single-title"><?php the_title(); ?></h1>
    </header>

    <?php if ( has_post_thumbnail() ) : ?>
        <div class="single-thumbnail" style="margin-bottom: 2rem; border-radius: 8px; overflow: hidden;">
            <?php the_post_thumbnail( 'large' ); ?>
        </div>
    <?php endif; ?>

    <div class="single-content">
        <?php the_content(); ?>
    </div>
</article>
