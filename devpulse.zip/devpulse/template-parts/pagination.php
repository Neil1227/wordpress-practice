<?php
/**
 * Template part for numeric post pagination
 *
 * @package DevPulse
 */

the_posts_pagination( array(
    'mid_size'           => 2,
    'prev_text'          => esc_html__( '&larr; Prev', 'devpulse' ),
    'next_text'          => esc_html__( 'Next &rarr;', 'devpulse' ),
    'screen_reader_text' => esc_html__( 'Posts navigation', 'devpulse' ),
    'class'              => 'pagination-partial',
) );
