<?php
/**
 * Template part for displaying a customizable Hero section
 *
 * Accepted $args:
 * - badge (string): Top pill text (default: 'WordPress Practice')
 * - title (string): Primary heading (default: Site Name)
 * - subtitle (string): Description text (default: Site Tagline)
 *
 * @package DevPulse
 */

$badge    = ! empty( $args['badge'] ) ? $args['badge'] : 'WordPress Practice';
$title    = ! empty( $args['title'] ) ? $args['title'] : get_bloginfo( 'name' );
$subtitle = ! empty( $args['subtitle'] ) ? $args['subtitle'] : get_bloginfo( 'description' );
?>

<section class="hero-partial">
    <?php if ( $badge ) : ?>
        <span class="hero-badge"><?php echo esc_html( $badge ); ?></span>
    <?php endif; ?>

    <h1 class="hero-title"><?php echo esc_html( $title ); ?></h1>

    <?php if ( $subtitle ) : ?>
        <p class="hero-subtitle"><?php echo esc_html( $subtitle ); ?></p>
    <?php endif; ?>
</section>
