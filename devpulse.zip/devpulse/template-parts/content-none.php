<?php
/**
 * Template part for displaying a message when no posts are found
 *
 * @package DevPulse
 */
?>

<section class="content-none">
    <h2><?php esc_html_e( 'Nothing Found', 'devpulse' ); ?></h2>
    
    <?php if ( is_search() ) : ?>
        <p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'devpulse' ); ?></p>
    <?php else : ?>
        <p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'devpulse' ); ?></p>
    <?php endif; ?>

    <div style="margin-top: 1.5rem;">
        <?php get_search_form(); ?>
    </div>
</section>
