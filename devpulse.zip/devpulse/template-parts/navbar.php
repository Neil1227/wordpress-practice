<?php
/**
 * Template part for displaying the top navigation bar
 *
 * @package DevPulse
 */
?>
<header class="site-header">
    <div class="navbar">
        <div class="brand-logo">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                <?php bloginfo( 'name' ); ?><span>.</span>
            </a>
        </div>

        <nav id="site-navigation" class="nav-menu">
            <?php
            if ( has_nav_menu( 'primary-menu' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary-menu',
                    'menu_id'        => 'primary-menu-list',
                    'container'      => false,
                    'fallback_cb'    => false,
                ) );
            } else {
                // Fallback links if no menu assigned yet
                echo '<ul>';
                echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Home</a></li>';
                echo '<li><a href="' . esc_url( home_url( '/sample-page' ) ) . '">Sample Page</a></li>';
                echo '</ul>';
            }
            ?>
        </nav>
    </div>
</header>
