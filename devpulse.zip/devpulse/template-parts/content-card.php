<?php
/**
 * Template part for displaying posts in a grid/card format
 *
 * Accepted $args:
 * - tag (string): Category or custom badge text override
 * - show_thumb (bool): Whether to show the thumbnail (default: true)
 *
 * @package DevPulse
 */

// Handle dynamic passed arguments with defaults
$show_thumb = isset( $args['show_thumb'] ) ? (bool) $args['show_thumb'] : true;
$tag_text   = ! empty( $args['tag'] ) ? $args['tag'] : ( has_category() ? get_the_category()[0]->name : 'Post' );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
    
    <?php if ( $show_thumb && has_post_thumbnail() ) : ?>
        <div class="post-card-thumbnail">
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail( 'medium_large' ); ?>
            </a>
        </div>
    <?php endif; ?>

    <div class="post-card-body">
        <div class="post-card-meta">
            <span class="post-card-badge"><?php echo esc_html( $tag_text ); ?></span>
            <time datetime="<?php echo get_the_date( 'c' ); ?>"><?php echo get_the_date(); ?></time>
        </div>

        <h2 class="post-card-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h2>

        <div class="post-card-excerpt">
            <?php the_excerpt(); ?>
        </div>

        <div class="post-card-footer">
            <span class="author-name">By <?php the_author(); ?></span>
            <a href="<?php the_permalink(); ?>" class="read-more">Read &rarr;</a>
        </div>
    </div>

</article>
