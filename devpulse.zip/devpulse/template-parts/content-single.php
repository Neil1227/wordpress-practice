<?php
/**
 * Template part for displaying single post content
 *
 * @package DevPulse
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-article' ); ?>>
    <header class="single-header">
        <h1 class="single-title"><?php the_title(); ?></h1>
        <div class="single-meta">
            <span>By <strong><?php the_author(); ?></strong></span>
            <span>Published on <?php echo get_the_date(); ?></span>
            <?php if ( has_category() ) : ?>
                <span>In <?php the_category( ', ' ); ?></span>
            <?php endif; ?>
        </div>
    </header>

    <?php if ( has_post_thumbnail() ) : ?>
        <div class="single-thumbnail" style="margin-bottom: 2rem; border-radius: 8px; overflow: hidden;">
            <?php the_post_thumbnail( 'large' ); ?>
        </div>
    <?php endif; ?>

    <div class="single-content">
        <?php
        the_content();

        wp_link_pages( array(
            'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'devpulse' ),
            'after'  => '</div>',
        ) );
        ?>
    </div>

    <?php if ( has_tag() ) : ?>
        <div class="single-tags" style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--border-color);">
            <strong>Tags: </strong><?php the_tags( '', ', ', '' ); ?>
        </div>
    <?php endif; ?>
</article>
