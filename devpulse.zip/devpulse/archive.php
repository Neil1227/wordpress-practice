<?php
/**
 * The template for displaying archive pages
 *
 * @package DevPulse
 */

get_header();

// Reusing the Hero partial with dynamic Archive title & description
get_template_part( 'template-parts/hero', null, array(
    'badge'    => 'Archive',
    'title'    => get_the_archive_title(),
    'subtitle' => get_the_archive_description() ?: 'Browsing archived articles.',
) );
?>

<div class="posts-grid">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();

            // Reusing the exact same post card partial
            get_template_part( 'template-parts/content', 'card', array(
                'tag' => has_category() ? get_the_category()[0]->name : 'Archive',
            ) );

        endwhile;
    else :
        get_template_part( 'template-parts/content', 'none' );
    endif;
    ?>
</div>

<?php
get_template_part( 'template-parts/pagination' );

get_footer();
