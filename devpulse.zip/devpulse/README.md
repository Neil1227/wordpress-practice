# DevPulse — WordPress Partials Practice Theme

A clean, modern WordPress practice theme specifically designed to teach and demonstrate **modular template parts (partials)** in WordPress.

---

## 📁 Project Structure & Partials Breakdown

```text
wordpress practice/
├── style.css                      # Theme info & styling tokens
├── functions.php                  # Theme setup, menus, enqueues
├── header.php                     # Global head & calls navbar partial
├── footer.php                     # Global footer & scripts
├── index.php                      # Main loop (calls hero, card, pagination partials)
├── single.php                     # Single post (calls content-single partial)
├── page.php                       # Single page (calls content-page partial)
├── archive.php                    # Archive view (re-uses hero & card partials)
├── 404.php                        # 404 error page (re-uses hero & none partials)
└── template-parts/
    ├── navbar.php                 # Site navigation bar partial
    ├── hero.php                   # Reusable banner partial accepting $args
    ├── content-card.php           # Post/Project card partial for loops
    ├── content-single.php         # Full post detail partial
    ├── content-page.php           # Static page content partial
    ├── content-none.php           # Empty state / search not found partial
    └── pagination.php             # Numeric pagination links partial
```

---

## 🎯 How Partials Work in this Project

### 1. Simple Template Part
```php
get_template_part( 'template-parts/navbar' );
// Looks for template-parts/navbar.php
```

### 2. Specialized Template Part with Fallback
```php
get_template_part( 'template-parts/content', 'card' );
// Looks for:
// 1. template-parts/content-card.php
// 2. template-parts/content.php (if card does not exist)
```

### 3. Passing Dynamic `$args` (WordPress 5.5+)
In `index.php` or `archive.php`:
```php
get_template_part( 'template-parts/hero', null, array(
    'badge'    => 'Custom Badge',
    'title'    => 'Dynamic Page Title',
    'subtitle' => 'Description text passed as argument',
) );
```
Inside `template-parts/hero.php`:
```php
$badge    = $args['badge'] ?? 'Default Badge';
$title    = $args['title'] ?? get_bloginfo( 'name' );
$subtitle = $args['subtitle'] ?? get_bloginfo( 'description' );
```

---

## 🚀 How to Test / Install in WordPress

1. Copy this entire folder (`wordpress practice`) into your WordPress installation's themes directory:
   ```text
   wp-content/themes/devpulse/
   ```
2. Open your WordPress Admin dashboard:
   - Navigate to **Appearance &rarr; Themes**.
   - Activate **DevPulse Practice Theme**.
3. Create a few practice posts with categories and featured images to see the dynamic partial cards and hero in action!

---

## 💡 Exercises to Try

1. **Create a `template-parts/content-quote.php` partial:**
   - Call `get_template_part( 'template-parts/content', get_post_format() );` to automatically load different card designs based on the post format (quote, gallery, video).
2. **Add a Author Bio Partial:**
   - Create `template-parts/author-bio.php` and include it at the bottom of `template-parts/content-single.php`.
3. **Pass Custom Color Flags:**
   - Pass `'accent_color' => '#f59e0b'` through `$args` to `template-parts/hero.php` and use it to tint specific category archive headers.
