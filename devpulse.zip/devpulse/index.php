<?php
/**
 * The main template file
 *
 * @package DevPulse
 */

get_header(); // 1. Load header partial

// 2. Load Hero partial with custom parameters
get_template_part( 'template-parts/hero', null, array(
    'badge'    => 'Featured Practice Theme',
    'title'    => 'Mastering WordPress Partials',
    'subtitle' => 'Explore modular templates, reusable template parts, and dynamic data passing in WordPress.',
) );
?>

<div class="posts-grid">
    <?php
    if ( have_posts() ) :

        /* Start the Loop */
        while ( have_posts() ) :
            the_post();

            /**
             * 3. Load Post Card Partial
             * WordPress will look for:
             * 1. template-parts/content-card.php
             * 2. template-parts/content.php (as fallback)
             */
            get_template_part( 'template-parts/content', 'card', array(
                'tag'        => has_category() ? get_the_category()[0]->name : 'Tutorial',
                'show_thumb' => true,
            ) );

        endwhile;

    else :

        // 4. Fallback partial if no posts exist
        get_template_part( 'template-parts/content', 'none' );

    endif;
    ?>
</div>

<?php
// 5. Load Pagination Partial
get_template_part( 'template-parts/pagination' );

get_footer(); // 6. Load footer partial
