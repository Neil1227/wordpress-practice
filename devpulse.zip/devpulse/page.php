<?php
/**
 * The template for displaying all single pages
 *
 * @package DevPulse
 */

get_header();
?>

<div class="page-wrapper">
    <?php
    while ( have_posts() ) :
        the_post();

        // Load the page content partial
        get_template_part( 'template-parts/content', 'page' );

    endwhile;
    ?>
</div>

<?php
get_footer();
