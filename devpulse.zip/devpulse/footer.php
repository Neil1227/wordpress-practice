    </main><!-- #primary .site-container -->

    <footer id="colophon" class="site-footer">
        <div class="footer-content">
            <p>
                &copy; <?php echo date( 'Y' ); ?> 
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>. 
                Built with custom <strong>WordPress Partials</strong>.
            </p>
        </div>
    </footer>

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
