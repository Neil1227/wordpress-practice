<?php
/**
 * The template for displaying the Front Page (Homepage)
 *
 * In WordPress hierarchy, front-page.php is ALWAYS loaded on the homepage,
 * regardless of whether WordPress is set to "Your latest posts" or "A static page".
 *
 * @package DevPulse
 */

get_header(); // 1. Load Navbar via header.php

// 2. Load Hero partial with custom parameters
get_template_part( 'template-parts/hero', null, array(
    'badge'    => 'DevPulse CMS Practice',
    'title'    => 'Building Fast Sites with Partials',
    'subtitle' => 'This page is rendered modularly using WordPress template parts and dynamic PHP components.',
) );
?>

<div class="posts-section">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <h2 style="font-size: 1.5rem; font-weight: 700; color: var(--text-main);">Latest Articles & Services</h2>
        <span style="color: var(--text-muted); font-size: 0.9rem;">Loaded from CMS</span>
    </div>

    <div class="posts-grid">
        <?php
        // Query the latest posts from WordPress database
        $latest_posts = new WP_Query( array(
            'post_type'      => 'post',
            'posts_per_page' => 6,
        ) );

        if ( $latest_posts->have_posts() ) :
            while ( $latest_posts->have_posts() ) :
                $latest_posts->the_post();

                // 3. Load Post Card Partial for each item
                get_template_part( 'template-parts/content', 'card', array(
                    'tag'        => has_category() ? get_the_category()[0]->name : 'General',
                    'show_thumb' => true,
                ) );

            endwhile;
            wp_reset_postdata();
        else :
            // 4. Fallback partial if no posts exist
            get_template_part( 'template-parts/content', 'none' );
        endif;
        ?>
    </div>
</div>

<?php
get_footer(); // 5. Load Footer
