<?php
/**
 * ApexCare Clinic Theme Functions
 *
 * @package ApexCare
 */

function apexcare_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 600, 380, true );

    register_nav_menus( array(
        'primary-menu' => esc_html__( 'Primary Clinic Menu', 'apexcare' ),
    ) );
}
add_action( 'after_setup_theme', 'apexcare_setup' );

function apexcare_scripts() {
    wp_enqueue_style( 'apexcare-style', get_stylesheet_uri(), array(), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'apexcare_scripts' );

/**
 * Register CTA Banner settings in WordPress Customizer
 */
function apexcare_customize_register( $wp_customize ) {
    // Create "CTA Banner Settings" section
    $wp_customize->add_section( 'apexcare_cta_section', array(
        'title'       => __( 'CTA Banner Settings', 'apexcare' ),
        'priority'    => 30,
        'description' => __( 'Customize the bottom Call-to-Action banner headlines and phone number.', 'apexcare' ),
    ) );

    // CTA Heading
    $wp_customize->add_setting( 'cta_title', array(
        'default'           => 'Need Urgent Dental or Medical Assistance?',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );
    $wp_customize->add_control( 'cta_title', array(
        'label'    => __( 'Banner Heading', 'apexcare' ),
        'section'  => 'apexcare_cta_section',
        'type'     => 'text',
    ) );

    // CTA Subtitle
    $wp_customize->add_setting( 'cta_subtitle', array(
        'default'           => 'Our emergency line is open 24/7. Walk-ins and new patients are always welcome with zero waiting time.',
        'sanitize_callback' => 'sanitize_textarea_field',
        'transport'         => 'refresh',
    ) );
    $wp_customize->add_control( 'cta_subtitle', array(
        'label'    => __( 'Banner Subtitle / Description', 'apexcare' ),
        'section'  => 'apexcare_cta_section',
        'type'     => 'textarea',
    ) );

    // CTA Phone Number
    $wp_customize->add_setting( 'cta_phone', array(
        'default'           => '(555) 019-2834',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ) );
    $wp_customize->add_control( 'cta_phone', array(
        'label'    => __( 'Emergency Phone Number', 'apexcare' ),
        'section'  => 'apexcare_cta_section',
        'type'     => 'text',
    ) );
}
add_action( 'customize_register', 'apexcare_customize_register' );
