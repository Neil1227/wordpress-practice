<?php
/**
 * Main Template File (Fallback)
 *
 * @package ApexCare
 */

get_header();

get_template_part( 'template-parts/hero', null, array(
    'badge'    => 'Clinic News & Articles',
    'title'    => 'Health & Dental Insights',
    'subtitle' => 'Latest advice and updates from our specialist practitioners.',
) );
?>

<div class="services-grid">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();
            get_template_part( 'template-parts/service-card' );
        endwhile;
    else :
        get_template_part( 'template-parts/content', 'none' );
    endif;
    ?>
</div>

<?php
get_footer();
