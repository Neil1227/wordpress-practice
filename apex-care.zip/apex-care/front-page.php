<?php
/**
 * The template for displaying the ApexCare Homepage
 *
 * @package ApexCare
 */

get_header(); // 1. Loads Header & Navbar

// 2. Load Hero Partial with custom copy
get_template_part( 'template-parts/hero', null, array(
    'badge'         => '✨ Modern Medical & Dental Specialists',
    'title'         => 'Advanced Care for Your Healthiest Smile & Body',
    'subtitle'      => 'Providing patient-first dental, cosmetic, and family healthcare with the latest pain-free technology.',
    'cta_primary'   => 'Book Appointment Online',
    'cta_secondary' => 'Explore All Services',
) );

// 3. Load Trust Badges / Stats Partial
get_template_part( 'template-parts/trust-badges' );
?>

<!-- Services Grid Section -->
<section id="services" style="margin-bottom: 4rem;">
    <div class="section-header-block">
        <span class="section-tag">What We Treat</span>
        <h2 class="section-main-title">Our Featured Clinical & Dental Treatments</h2>
    </div>

    <div class="services-grid">
        <?php
        $services_query = new WP_Query( array(
            'post_type'      => 'post',
            'posts_per_page' => 6,
        ) );

        if ( $services_query->have_posts() ) :
            while ( $services_query->have_posts() ) :
                $services_query->the_post();

                // 4. Load Service Card Partial
                get_template_part( 'template-parts/service-card' );

            endwhile;
            wp_reset_postdata();
        else :
            get_template_part( 'template-parts/content', 'none' );
        endif;
        ?>
    </div>
</section>

<?php
// 5. Load Doctors & Medical Specialists Team Partial
get_template_part( 'template-parts/doctors-team', null, array(
    'title'    => 'Meet Our Specialist Practitioners',
    'subtitle' => 'Our board-certified doctors and dental surgeons bring over 40+ combined years of clinical expertise.',
) );

// 6. Load Urgent CTA Banner Partial (managed via Appearance -> Customize)
get_template_part( 'template-parts/cta-banner' );

get_footer(); // 7. Loads Footer
