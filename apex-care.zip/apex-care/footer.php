</main><!-- #primary .site-container -->

<footer class="site-footer">
    <div class="footer-grid">
        <div class="footer-col">
            <h4><?php bloginfo( 'name' ); ?></h4>
            <p>Providing premium, patient-centered healthcare, cosmetic dental, and preventive treatments for families and professionals.</p>
        </div>
        <div class="footer-col">
            <h4>Working Hours</h4>
            <p>Monday – Friday: 8:00 AM – 6:00 PM<br>Saturday: 9:00 AM – 2:00 PM<br>Sunday: Closed</p>
        </div>
        <div class="footer-col">
            <h4>Contact Info</h4>
            <p>Email: care@apexclinic.com<br>Phone: (555) 019-2834<br>Location: 123 Healthcare Blvd</p>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?>. Built with modular <strong>WordPress Partials</strong>.</p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
