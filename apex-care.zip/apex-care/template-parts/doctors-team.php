<?php
/**
 * Doctors & Medical Specialists Team Partial
 *
 * Accepted $args:
 * - title (string): Section heading
 * - subtitle (string): Section subtext
 *
 * @package ApexCare
 */

$sec_title = $args['title'] ?? 'Meet Our Specialist Practitioners';
$sec_sub   = $args['subtitle'] ?? 'Our board-certified doctors and dental surgeons bring over 40+ combined years of clinical expertise.';
?>

<section id="doctors" class="doctors-section">
    <div class="section-header-block">
        <span class="section-tag">Clinical Excellence</span>
        <h2 class="section-main-title"><?php echo esc_html( $sec_title ); ?></h2>
        <p style="color: var(--text-muted); max-width: 620px; margin: 0.5rem auto 0 auto;">
            <?php echo esc_html( $sec_sub ); ?>
        </p>
    </div>

    <div class="doctors-grid">
        
        <!-- Doctor Card 1 -->
        <div class="doctor-card">
            <div class="doctor-avatar">
                <span class="avatar-icon">👨‍⚕️</span>
            </div>
            <div class="doctor-info">
                <span class="doctor-specialty">Chief Dental Surgeon</span>
                <h3 class="doctor-name">Dr. Marcus Vance, DDS</h3>
                <p class="doctor-bio">Specializing in painless cosmetic dentistry, dental implants, and smile reconstruction with 16+ years experience.</p>
                <div class="doctor-footer">
                    <span class="doctor-exp">⭐ 4.9 (320+ Reviews)</span>
                    <a href="#appointment" class="btn-doc-book">Book Visit &rarr;</a>
                </div>
            </div>
        </div>

        <!-- Doctor Card 2 -->
        <div class="doctor-card">
            <div class="doctor-avatar">
                <span class="avatar-icon">👩‍⚕️</span>
            </div>
            <div class="doctor-info">
                <span class="doctor-specialty">Orthodontics Specialist</span>
                <h3 class="doctor-name">Dr. Elena Rostova, DMD</h3>
                <p class="doctor-bio">Expert in Invisalign, clear aligners, and adolescent corrective orthodontics using 3D digital smile mapping.</p>
                <div class="doctor-footer">
                    <span class="doctor-exp">⭐ 5.0 (280+ Reviews)</span>
                    <a href="#appointment" class="btn-doc-book">Book Visit &rarr;</a>
                </div>
            </div>
        </div>

        <!-- Doctor Card 3 -->
        <div class="doctor-card">
            <div class="doctor-avatar">
                <span class="avatar-icon">🩺</span>
            </div>
            <div class="doctor-info">
                <span class="doctor-specialty">Preventive Healthcare</span>
                <h3 class="doctor-name">Dr. Julian Hayes, MD</h3>
                <p class="doctor-bio">Focused on comprehensive family health checkups, cardiovascular wellness, and preventative lifestyle medicine.</p>
                <div class="doctor-footer">
                    <span class="doctor-exp">⭐ 4.9 (410+ Reviews)</span>
                    <a href="#appointment" class="btn-doc-book">Book Visit &rarr;</a>
                </div>
            </div>
        </div>

    </div>
</section>
