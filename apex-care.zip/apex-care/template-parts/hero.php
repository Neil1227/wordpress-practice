<?php
/**
 * Hero Banner Partial
 *
 * $args options:
 * - badge (string)
 * - title (string)
 * - subtitle (string)
 * - cta_primary (string)
 * - cta_secondary (string)
 *
 * @package ApexCare
 */

$badge         = $args['badge'] ?? '🏆 #1 Rated Dental & Medical Care in 2026';
$title         = $args['title'] ?? 'Exceptional Care for Your Healthiest Smile';
$subtitle      = $args['subtitle'] ?? 'Experience gentle, modern dentistry and medical services powered by advanced technology and board-certified specialists.';
$cta_primary   = $args['cta_primary'] ?? 'Book Consultation';
$cta_secondary = $args['cta_secondary'] ?? 'View Our Services';
?>

<section class="hero-medical">
    <div class="hero-pill">
        <?php echo esc_html( $badge ); ?>
    </div>

    <h1 class="hero-headline">
        <?php echo esc_html( $title ); ?>
    </h1>

    <p class="hero-subtext">
        <?php echo esc_html( $subtitle ); ?>
    </p>

    <div class="hero-cta-group">
        <a href="#appointment" class="btn-appointment" style="font-size: 1rem; padding: 0.8rem 2rem;">
            <?php echo esc_html( $cta_primary ); ?> &rarr;
        </a>
        <a href="#services" class="btn-secondary" style="font-size: 1rem; padding: 0.8rem 1.75rem;">
            <?php echo esc_html( $cta_secondary ); ?>
        </a>
    </div>
</section>
