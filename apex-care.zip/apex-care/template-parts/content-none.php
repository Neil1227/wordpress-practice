<?php
/**
 * Empty State Partial
 *
 * @package ApexCare
 */
?>

<div style="background: #ffffff; border: 1px dashed var(--border-light); border-radius: var(--radius-md); padding: 3rem; text-align: center; max-width: 600px; margin: 2rem auto;">
    <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem; color: #0f172a;">No Services Listed Yet</h3>
    <p style="color: var(--text-muted); margin-bottom: 1.5rem;">Add some services or articles in the WordPress Admin to display them here.</p>
</div>
