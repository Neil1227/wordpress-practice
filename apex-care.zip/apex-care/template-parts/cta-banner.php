<?php
/**
 * Booking Call-To-Action Banner Partial
 *
 * Dynamically fetches values from WordPress Customizer (Appearance -> Customize),
 * with fallbacks to $args or defaults.
 *
 * @package ApexCare
 */

$cta_heading  = get_theme_mod( 'cta_title', $args['title'] ?? 'Need Urgent Dental or Medical Assistance?' );
$cta_text     = get_theme_mod( 'cta_subtitle', $args['subtitle'] ?? 'Our emergency line is open 24/7. Walk-ins and new patients are always welcome with zero waiting time.' );
$cta_phone    = get_theme_mod( 'cta_phone', $args['phone'] ?? '(555) 019-2834' );
$numeric_phone = preg_replace( '/[^0-9]/', '', $cta_phone );
?>

<section id="appointment" class="cta-banner-partial">
    <h2 class="cta-banner-title"><?php echo esc_html( $cta_heading ); ?></h2>
    <p class="cta-banner-sub"><?php echo esc_html( $cta_text ); ?></p>
    
    <a href="tel:<?php echo esc_attr( $numeric_phone ); ?>" class="btn-cta-white">
        📞 Call <?php echo esc_html( $cta_phone ); ?> Now
    </a>
</section>
