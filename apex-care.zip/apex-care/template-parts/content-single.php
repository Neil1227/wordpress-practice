<?php
/**
 * Single Treatment / Article Partial
 *
 * @package ApexCare
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-service-article' ); ?> style="background: #ffffff; padding: 2.5rem; border-radius: var(--radius-md); border: 1px solid var(--border-light); box-shadow: var(--shadow-sm); max-width: 850px; margin: 0 auto 3rem auto;">
    <header style="margin-bottom: 2rem; border-bottom: 1px solid var(--border-light); padding-bottom: 1.5rem;">
        <h1 style="font-size: 2.4rem; font-weight: 800; color: #0f172a; margin-bottom: 0.75rem;"><?php the_title(); ?></h1>
        <div style="color: var(--text-muted); font-size: 0.95rem;">
            <span>Category: <strong><?php the_category(', '); ?></strong></span> &bull; 
            <span>Published: <?php echo get_the_date(); ?></span>
        </div>
    </header>

    <?php if ( has_post_thumbnail() ) : ?>
        <div style="margin-bottom: 2rem; border-radius: var(--radius-sm); overflow: hidden;">
            <?php the_post_thumbnail( 'large' ); ?>
        </div>
    <?php endif; ?>

    <div style="font-size: 1.1rem; line-height: 1.8; color: #334155;">
        <?php the_content(); ?>
    </div>
</article>
