<?php
/**
 * Navigation Bar Partial with Quick Appointment CTA
 *
 * @package ApexCare
 */
?>
<header class="site-header">
    <div class="navbar">
        <div class="brand-logo">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                Apex<span>Care+</span>
            </a>
        </div>

        <nav class="nav-menu">
            <?php
            if ( has_nav_menu( 'primary-menu' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'primary-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                ) );
            } else {
                echo '<ul>';
                echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Services</a></li>';
                echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Doctors</a></li>';
                echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">About</a></li>';
                echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Contact</a></li>';
                echo '</ul>';
            }
            ?>
        </nav>

        <div>
            <a href="#appointment" class="btn-appointment">📅 Book Appointment</a>
        </div>
    </div>
</header>
