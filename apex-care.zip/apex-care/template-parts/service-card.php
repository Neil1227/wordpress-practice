<?php
/**
 * Service / Treatment Card Partial
 *
 * @package ApexCare
 */

$category_name = has_category() ? get_the_category()[0]->name : 'Treatment';
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'service-card' ); ?>>
    <?php if ( has_post_thumbnail() ) : ?>
        <div class="service-card-thumb">
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail( 'medium_large' ); ?>
            </a>
        </div>
    <?php endif; ?>

    <div class="service-card-content">
        <span class="service-category-tag"><?php echo esc_html( $category_name ); ?></span>

        <h3 class="service-card-title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>

        <div class="service-card-desc">
            <?php the_excerpt(); ?>
        </div>

        <div class="service-card-foot">
            <span style="color: var(--primary);">🩺 Available Today</span>
            <a href="<?php the_permalink(); ?>" style="font-weight: 700;">Details &rarr;</a>
        </div>
    </div>
</article>
