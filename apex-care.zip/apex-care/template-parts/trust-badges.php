<?php
/**
 * Trust Badges / Stats Partial
 *
 * @package ApexCare
 */
?>
<section class="trust-badges-grid">
    <div class="trust-badge-card">
        <div class="trust-badge-icon">👨‍⚕️</div>
        <h3 class="trust-badge-title">Board Certified</h3>
        <p class="trust-badge-desc">Over 15+ years of clinical excellence & specialists.</p>
    </div>

    <div class="trust-badge-card">
        <div class="trust-badge-icon">⚡</div>
        <h3 class="trust-badge-title">Pain-Free Tech</h3>
        <p class="trust-badge-desc">State-of-the-art gentle laser & 3D scan equipment.</p>
    </div>

    <div class="trust-badge-card">
        <div class="trust-badge-icon">⭐</div>
        <h3 class="trust-badge-title">4.9/5 Rating</h3>
        <p class="trust-badge-desc">Trusted by more than 8,500 happy patient families.</p>
    </div>

    <div class="trust-badge-card">
        <div class="trust-badge-icon">🛡️</div>
        <h3 class="trust-badge-title">Insurance Accepted</h3>
        <p class="trust-badge-desc">Direct billing with 99% of major medical providers.</p>
    </div>
</section>
