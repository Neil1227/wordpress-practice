<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Top Emergency / Notice Strip -->
<div class="top-notice-bar">
    <div class="top-notice-content">
        <span>📍 123 Healthcare Blvd, Suite 400 &bull; Open Mon-Sat 8am - 6pm</span>
        <span>Emergency Dental Line: <strong>(555) 019-2834</strong></span>
    </div>
</div>

<!-- Reusable Navbar Partial -->
<?php get_template_part( 'template-parts/navbar' ); ?>

<main id="primary" class="site-container">
